package com.plug.hookplug.plug

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam

class fqxs : IXposedHookLoadPackage {
    @Throws(Throwable::class)
    override fun handleLoadPackage(lpparam: LoadPackageParam) {
        if (lpparam.packageName == "com.dragon.read") {
            XposedHelpers.findAndHookMethod(
                    "com.dragon.read.component.audio.impl.ui.c.a",
                    lpparam.classLoader,
                    "a",
                    Context::class.java,
                    String::class.java,
                    String::class.java,
                    object : XC_MethodHook() {
                        @Throws(Throwable::class)
                        override fun afterHookedMethod(param: MethodHookParam) {
                            //去除听书页面热门直播间
                            param.result = null
                        }
                    }
            )
            XposedHelpers.findAndHookMethod(
                    "com.dragon.read.user.h",
                    lpparam.classLoader,
                    "j",
                    object : XC_MethodHook() {
                        @Throws(Throwable::class)
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            //去除广告
                            param.result = true
                        }
                    }
            )
            XposedHelpers.findAndHookMethod(
                    "com.dragon.read.user.h",
                    lpparam.classLoader,
                    "isForeverNoAd",
                    object : XC_MethodHook() {
                        @Throws(Throwable::class)
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            //去除广告
                            param.result = true
                        }
                    }
            )
            XposedHelpers.findAndHookMethod(
                    "com.ss.android.update.ad",
                    lpparam.classLoader,
                    "k",
                    object : XC_MethodHook() {
                        @Throws(Throwable::class)
                        override fun afterHookedMethod(param: MethodHookParam) {
                            //去除更新
                            param.result = false
                        }
                    }
            )
            XposedHelpers.findAndHookMethod(
                    "com.dragon.read.polaris.d",
                    lpparam.classLoader,
                    "b",
                    object : XC_MethodHook() {
                        @Throws(Throwable::class)
                        override fun afterHookedMethod(param: MethodHookParam) {
                            //去除福利悬浮红包让其显示的更加干净
                            param.result = false
                        }
                    }
            )
            XposedHelpers.findAndHookConstructor(
                    "com.dragon.read.user.model.VipInfoModel",
                    lpparam.classLoader,
                    String::class.java,
                    String::class.java,
                    String::class.java,
                    Boolean::class.javaPrimitiveType,
                    Boolean::class.javaPrimitiveType,
                    Int::class.javaPrimitiveType,
                    Boolean::class.javaPrimitiveType,
                    object : XC_MethodHook() {
                        @Throws(Throwable::class)
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            param.args[0] = "218330035688"
                            param.args[1] = "1"
                            param.args[2] = "10000"
                            param.args[3] = true
                            param.args[4] = true
                            param.args[5] = 1
                            param.args[6] = true
                            //老生常谈VIP
                        }
                    }
            )
        }
    }
}